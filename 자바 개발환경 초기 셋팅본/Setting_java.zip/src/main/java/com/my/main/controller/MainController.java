package com.my.main.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.my.main.service.MainService;
import com.my.security.SecurityUserDetail;

@Controller
public class MainController {

	@Autowired
	private MainService mainService;
	
	
	/*=========================EXAMPLE==========================*/
	@RequestMapping("/")
	public String index(Authentication authentication) {
		SecurityUserDetail user = (SecurityUserDetail) authentication.getPrincipal();
		System.out.println(user);
		return "index";
	}

	@RequestMapping("/login/loginPage")
	public String login() {
		return "login/loginPage";
	}
	
	@RequestMapping("/aaaa")
	@ResponseBody
	public Map<String, Object> aaaa(@RequestParam Map<String, Object> reqMap) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("result", mainService.selectStudentAttend(reqMap));
		return map;
	}
	/*=========================EXAMPLE==========================*/
	
	
	
	/**
	 * 테스트 페이지(화면)
	 * @method : testPage
	 * @create : 2020-10-14
	 * @param model
	 * @author : MH.Heo
	 * @throws Exception 
	 */
	@RequestMapping("/system/testPage.do")
	public String testPage(Model model,@RequestParam Map<String, Object> reqMap, Authentication authentication) {
		SecurityUserDetail user = (SecurityUserDetail) authentication.getPrincipal();
		
		System.out.println("-------------------- "+user.getNickname()+" 접속"+" --------------------");
		
		return "system/main";
	}
	
	/**
	 * 테스트 페이지2(화면)
	 * @method : testPage2
	 * @create : 2020-10-14
	 * @param model
	 * @author : MH.Heo
	 * @throws Exception 
	 */
	@RequestMapping("/system/testPage2.do")
	public String testPage2(Model model,@RequestParam Map<String, Object> reqMap, Authentication authentication) {
		SecurityUserDetail user = (SecurityUserDetail) authentication.getPrincipal();
		
		System.out.println("-------------------- "+user.getNickname()+" 접속"+" --------------------");
		
		return "system/main2";
	}
}
